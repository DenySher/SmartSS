import Button from '../Button/Button'
import Form from '../Form/Form'
import styles from './LoginForm.module.scss'

const LoginForm = () => {

    // const startLogin = () => {
    //     someQuery().then((res) => {
    //         if (res.token) {
    //             navigate()
    //         }
    //     })
    // }
    
    return (
        <div className={styles.containerLogIn}>
            <Form>
                <input type='text' placeholder="Login"/>
                <input type='password' placeholder="Password"/>
                <Button text='Войти' />
            </Form>
        </div>
    )
}

export default LoginForm