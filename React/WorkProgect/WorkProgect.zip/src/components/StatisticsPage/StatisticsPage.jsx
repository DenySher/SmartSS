
const StatisticsPage = () => {
    return (
        <>
        <p> Sheremetev </p>
        </>
    )
}

export default StatisticsPage