import {useState} from 'react'
import Form from '../Form/Form'
import Button from '../Button/Button'
import styles from './CreateProject.module.scss'

const CreateProject = () => {

    const [workers, setWorkers] = useState([]);

    return (
        <div className={styles.containerCreateName}>
            <Form>
                <input placeholder='Наименование стройки'/>
                <input placeholder='Адрес стройки'/>
                <input placeholder='Прораб' />
                <div>
                    <input placeholder='Рабочий' />
                    <Button text='+' />
                </div>
                <button>Прайс работы +</button>
                <button>Поставка оборудования +</button>
                <button>Поставка инструмента +</button>

                {workers.length > 0 && <input placeholder='Рабочий'/>}
            </Form>
        </div>
    )
}

export default CreateProject