import styles from './CardProject.module.scss'


const CardProject = () => {
    return (
    <div className={styles.dataProject}>
        <div className={styles.nameData}>
            <div><p>Наименование</p></div>
            <div><p>Адрес</p></div>
            <div><p>Прораб</p></div>
            <div><p>Рабочиe</p></div>
            <div><p>Работы прайс</p></div>
            <div><p>Поставка оборудования</p></div>
            <div><p>Инструменты</p></div>
        </div>
        <div className={styles.showData}>
            <div><span>ЖК Ленинская Слобода</span></div>
            <div><span>г.Москва, ленинская Слобода, вл.3</span></div>
            <div><span>Филлипчиков Степан Леонидович</span></div>
            <div><span>Открыть</span></div>
            <div><span>Открыть</span></div>
            <div><span>Открыть</span></div>
            <div><span>Открыть</span></div>
        </div>
    </div>

    )
}

export default CardProject