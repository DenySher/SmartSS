import styles from './UserName.module.scss'

const UserName = () => {
    return (
        
        <div>
            <span className={styles.u}>User name</span>
        </div>
    )
}

export default UserName