import styles from './Button.module.scss';

const Button = ({onPress, text}) => {
	return (
		<button className={styles.btn} onPress={onPress}>{text}</button>
	)
}

export default Button;