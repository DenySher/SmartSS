import CardProject from "../../components/CardProgect/CardProject"

const CardProjectPage = () => {
    return (
        <CardProject />
    )
}

export default CardProjectPage