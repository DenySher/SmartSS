import CreateProject from '../../components/CreateProject/CreateProject'

const CreateProjectPage = () => {
    return (
        <CreateProject />
    )
}

export default CreateProjectPage