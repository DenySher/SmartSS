import Header from './components/Header/Header'

import LoginPage from './pages/Login/LoginPage';
import CreateProjectPage from './pages/CreateProject/CreateProgectPage';
import CardProjectPage from './pages/CardProject/CardProjectPage';

import { Route, Routes, Link } from 'react-router-dom'

function App(props) {
  return (
    <div className="App">
      <div className='container'>
        <Header />
        <Routes>
          <Route path='login' element={<LoginPage />} />
          <Route path='CreateProject' element={<CreateProjectPage />} />
          <Route path='CardProject' element={<CardProjectPage/>} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
